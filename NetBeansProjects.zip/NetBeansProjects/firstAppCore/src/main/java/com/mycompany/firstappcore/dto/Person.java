/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.firstappcore.dto;

/**
 *
 * @author samihhabbani
 */
public class Person {
    
    private String firstName;
    private String name;

    public Person() {
    }

    public Person(String firstName, String name) {
        this.firstName = firstName;
        this.name = name;
    }
    

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    
    public String getFullName() {
        return this.firstName + " " + this.name;
    }
   
}
