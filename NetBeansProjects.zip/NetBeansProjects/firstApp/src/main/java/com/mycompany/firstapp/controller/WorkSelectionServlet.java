/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package com.mycompany.firstapp.controller;

import com.mycompany.firstappcore.dto.Book;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author samihhabbani
 */
@WebServlet(name = "WorkSelectionServlet2", urlPatterns = {"/work-selection2"})
public class WorkSelectionServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet WorkSelectionServlet</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet WorkSelectionServlet at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
       
        // comment je créé une session
        // je la récupère si elle existe
        HttpSession session = request.getSession();
        // tomcat va regarder si une sessoion est déjà en place
        // si un numero de session a déjà été attribué
        // si c'est le cas il va récupérer la session
        // sinon il va la créer en générant un numéro de session
        String numeroSession = session.getId();
        
        String id = request.getParameter("id");
        
        // j'alimente ma session en y ajoutant l'id de l'oeuvre selectionnée :)
        // session.setAttribute("workNumber", id);   
        
        Book book = new Book();
        book.setBookNumber(Long.parseLong(id));
        
        // que se passe-t-il ici au niveau des JSP EL si j'ai rien en session?
        //session.setAttribute("book", book);
        
        PrintWriter out = response.getWriter();
        /* TODO output your page here. You may use following sample code. */
        out.println("<!DOCTYPE html>");
        out.println("<html>");
        out.println("<head>");
        out.println("<title>Votre selecton</title>");            
        out.println("</head>");
        out.println("<body>");
        out.println("<h1> Merci d'avoir sélectionné l'oeuvre n°" + session.getAttribute("workNumber") + " </h1>");
        out.println("<a href='pay-work.html'> Payer maintenant </a>");
        out.println("<p> Numéro de session : " + numeroSession + " </p>");
        out.println("</body>");
        out.println("</html>");
        
        
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
