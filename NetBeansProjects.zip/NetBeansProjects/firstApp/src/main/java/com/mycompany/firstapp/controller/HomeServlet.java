/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.firstapp.controller;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author samihhabbani
 */
@WebServlet(name="HomeServlet", urlPatterns = {"/home"}) // chemin virtuel
public class HomeServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        
        System.out.println("Hello World");
        
        PrintWriter out = resp.getWriter();
        out.println("<html><body>");
        out.println("<h1>Welcome in Home Page !</h1>");
        out.println("</body></html>");
             
        
    }
    
}
