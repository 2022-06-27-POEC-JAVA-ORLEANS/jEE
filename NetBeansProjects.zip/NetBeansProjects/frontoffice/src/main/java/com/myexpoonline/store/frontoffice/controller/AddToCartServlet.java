/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package com.myexpoonline.store.frontoffice.controller;

import com.myexpoonline.store.core.entity.Catalogue;
import com.myexpoonline.store.core.entity.ShoppingCart;
import com.myexpoonline.store.core.entity.Work;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Optional;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author samihhabbani
 */
@WebServlet(name = "AddToCartServlet", urlPatterns = {"/addToCart"})
public class AddToCartServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet AddToCartServlet</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet AddToCartServlet at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
       
        // je récupère ma session
        HttpSession session = request.getSession();
        
        // je récupère la valeur de l'id ajouté au panier
        Long id = Long.parseLong(request.getParameter("id-work"));
         
        // je vais récupérer mon panier
        ShoppingCart cart = (ShoppingCart) session.getAttribute("cart");
        
        // si j'avais pas de panier en session j'en créé un
        if(cart == null) {
            cart = new ShoppingCart();
            session.setAttribute("cart", cart);
        }
        
        Optional<Work> optionalWork = Catalogue.listOfWorks.stream().filter(w -> w.getId() == id).findAny();

        PrintWriter out = response.getWriter();
        /* TODO output your page here. You may use following sample code. */
        out.println("<!DOCTYPE html>");
        out.println("<html>");
        out.println("<head>");
        out.println("<title>Ajout de l'oeuvre</title>");            
        out.println("</head>");
        out.println("<body>");
        
        if(optionalWork.isPresent()) {
            cart.getItems().add(optionalWork.get());
            out.println("<h1>Votre oeuvre a bien été ajoutée au panier(" + cart.getItems().size() + ")</h1>");
        } else {
            out.println("<h1>Une erreur est survenue votre produit n'a pas été ajouté au panier</h1>");
        }
        
        out.println("<table border='1'>");
        // Les titres
        out.println("<tr>");
        out.println("<th>Titre</th>");
        out.println("<th>Style</th>");
        out.println("<th>Année</th>");
        out.println("<th>Quantité</th>");
        out.println("</tr>");
        
        if(!cart.getItems().isEmpty()) {
            
            for(Work work : cart.getItems()) {
                // Les données
                out.println("<tr>");
                out.println("<td>"+work.getTitle()+"</td>");
                out.println("<td>"+work.getStyle()+"</td>");
                out.println("<td>"+work.getYear()+"</td>");
                out.println("<td>1</td>");
                out.println("</tr>");
            }
            
        } else {
            out.println("<tr> <td colspan='4'> Panier vide !  </td> </tr>");
        }
        
        out.println("</table>");
        out.println("<a href='catalogue'> Retourner au catalogue </a>");
        out.println("</body>");
        out.println("</html>");
        // afficher un msg de confirmation si l'oeuvre a correctement été ajoutée
        // et le total d'oeuvre dans mon chariot
        // sion un msg d'erreur
        
        // bonus : 
        // afficher les oeuvres en session dans un tableau HTML ou vous afficherez :
        // Titre
        // Année
        // Style
        // Quantité
       
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
